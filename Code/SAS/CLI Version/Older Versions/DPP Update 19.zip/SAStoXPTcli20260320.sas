/*------------------------------------------------------------------*
| PROGRAM NAME : SAStoXPTcli20260320.sas
| SHORT DESC   : Bidirectional batch conversion between SAS7BDAT
|                and XPT (SAS Transport) formats via CLI
*------------------------------------------------------------------*
| CREATED BY   : DAC Development Team
| DATE CREATED : 2025-11-21
| VERSION      : 2.1
*------------------------------------------------------------------*
| VERSION UPDATES:
| 2025-11-21: Initial CLI release (v2.0)
|   - Added SYSPARM parsing for input and output directories
|   - Added bidirectional conversion (SAS7BDAT <-> XPT)
|   - Added automatic creation of DAC_XPT and DAC_SDTM subfolders
|   - Added conversion error log generation
| 2026-03-20: File standardized to 20260320 naming convention
|   - No functional changes; header and filename updated to match
|     the pipeline versioning convention used across all CLI scripts
| 2026-05-19: Fixed dcreate return-value check (v2.1)
|   - Replaced `%if &rc = %then` with `%if %length(&rc) = 0 %then`
|     for all three directory-creation guards (DAC_Logs, DAC_XPT,
|     DAC_SDTM). dcreate returns the new directory name (a string)
|     on success, causing %EVAL to abort with "character operand
|     found where numeric operand required" when the %if condition
|     tried to compare that string numerically. Using %length()
|     correctly detects an empty return value (failure) without
|     triggering a numeric-evaluation error.
*------------------------------------------------------------------*
| PURPOSE
| Performs batch bidirectional conversion of SAS datasets between
| SAS7BDAT and XPT (SAS Transport) formats. When .sas7bdat files
| are detected in the input directory they are converted to .xpt
| and placed in OUTDIR\DAC_XPT. When .xpt files are detected they
| are converted to .sas7bdat and placed in OUTDIR\DAC_SDTM. Both
| conversion types may occur in a single run. An error log
| (xpt_error_log.txt) is written to the DAC_Logs subdirectory.
|
| 1.0: REQUIRED SYSPARM PARAMETERS (pipe-delimited)
| INPUT_DIRECTORY  = Path to folder containing .sas7bdat or .xpt
|                    files to be converted
| OUTPUT_DIRECTORY = Path to folder where output subfolders and
|                    the error log will be created. Must exist
|                    prior to execution.
|
| 2.0: XPT FORMAT LIMITATIONS
| MEMBER NAMES     = Limited to 8 characters by the XPT format
|                    specification. Dataset names longer than 8
|                    characters are automatically truncated to the
|                    first 4 characters concatenated with the last
|                    4 characters.
|                    Example: "berkeley_pbo_ae" becomes "berkl_ae"
|
| USAGE:
|   sas -sysparm "input_directory|output_directory"
|       -sysin SAStoXPTcli20260320.sas
|
| OUTPUT STRUCTURE:
|   output_directory\
|   ├── DAC_XPT\          - XPT exports (from .sas7bdat input)
|   ├── DAC_SDTM\         - SAS7BDAT exports (from .xpt input)
|   └── DAC_Logs\
|       └── xpt_error_log.txt - Conversion activity and error log
*------------------------------------------------------------------*
| OPERATING SYSTEM COMPATIBILITY
| SAS v9.4 or Higher: Yes
| Windows:            Yes (uses DIR command for file listing)
*------------------------------------------------------------------*
| MACRO CALL
|
| Not applicable. Script is invoked directly via the SAS command
| line using -sysin and -sysparm.
*------------------------------------------------------------------*
| EXAMPLES
|
| Convert SAS datasets to XPT format:
|   sas -sysparm "C:\data\input|C:\data\output"
|       -sysin SAStoXPTcli20260320.sas
|
| Convert XPT files back to SAS7BDAT:
|   sas -sysparm "C:\data\xpt_files|C:\data\output"
|       -sysin SAStoXPTcli20260320.sas
|
| Process a mixed directory (both .sas7bdat and .xpt present):
|   sas -sysparm "C:\data\mixed|C:\data\output"
|       -sysin SAStoXPTcli20260320.sas
*------------------------------------------------------------------*/

%macro convert_files;
    %let sysparm_value = &sysparm;
    %put DEBUG: Raw SYSPARM value = &sysparm_value;

    %let pipe_pos = %sysfunc(findc(&sysparm_value, |));
    %put DEBUG: Pipe position = &pipe_pos;

    %if &pipe_pos > 0 %then %do;
        %let indir = %substr(&sysparm_value, 1, %eval(&pipe_pos - 1));
        %let outdir = %substr(&sysparm_value, %eval(&pipe_pos + 1));
    %end;
    %else %do;
        %put ERROR: Invalid SYSPARM format. Expected: input_directory|output_directory;
        %abort;
    %end;

    %put DEBUG: Input Directory = &indir;
    %put DEBUG: Output Directory = &outdir;

    %let indir_exist = %sysfunc(fileexist(&indir));
    %let outdir_exist = %sysfunc(fileexist(&outdir));

    %if &indir_exist = 0 %then %do;
        %put ERROR: Input directory does not exist: &indir;
        %abort;
    %end;

    %if &outdir_exist = 0 %then %do;
        %put ERROR: Output directory does not exist: &outdir;
        %abort;
    %end;

    /* Create DAC_Logs subfolder if it does not exist */
    %let dac_logs_dir = &outdir\DAC_Logs;
    %let dac_logs_exist = %sysfunc(fileexist(&dac_logs_dir));
    %if &dac_logs_exist = 0 %then %do;
        %let rc = %sysfunc(dcreate(DAC_Logs, &outdir));
        %if %length(&rc) = 0 %then %do;
            %put ERROR: Failed to create directory &dac_logs_dir;
            %abort;
        %end;
    %end;

    %let errlog = &outdir\DAC_Logs\xpt_error_log.txt;

    data _null_;
        file "&errlog";
        length dt $19;
        dt = put(datetime(), datetime19.);
        put "Error Log - " dt;
        put "Input Directory: &indir";
        put "Output Directory: &outdir";
        put "----------------------------------------";
    run;

    filename infiles pipe "dir /b ""&indir\*.sas7bdat"" ""&indir\*.xpt"" 2>nul";

    data file_list;
        infile infiles truncover;
        input filename $256.;
        length filetype $10;
        if index(upcase(filename), '.SAS7BDAT') > 0 then filetype = 'SAS7BDAT';
        else if index(upcase(filename), '.XPT') > 0 then filetype = 'XPT';
    run;

    filename infiles clear;

    proc sql noprint;
        select count(*) into :sas7bdat_count trimmed from file_list where filetype = 'SAS7BDAT';
        select count(*) into :xpt_count trimmed from file_list where filetype = 'XPT';
    quit;

    %put DEBUG: Found &sas7bdat_count SAS7BDAT files;
    %put DEBUG: Found &xpt_count XPT files;

    %if &sas7bdat_count > 0 %then %do;
        %let xpt_dir = &outdir\DAC_XPT;
        %let xpt_exist = %sysfunc(fileexist(&xpt_dir));

        %if &xpt_exist = 0 %then %do;
            %put DEBUG: Creating directory &xpt_dir;
            %let rc = %sysfunc(dcreate(DAC_XPT, &outdir));
            %if %length(&rc) = 0 %then %do;
                %put ERROR: Failed to create directory &xpt_dir;
                %abort;
            %end;
        %end;

        libname inlib "&indir";

        data _null_;
            set file_list end=eof;
            where filetype = 'SAS7BDAT';

            length dsname memname $32 xpt_path $256;

            dsname = scan(filename, 1, '.');

            /* Truncate to first 4 + last 4 characters for XPT compliance */
            if length(dsname) > 8 then
                memname = substr(dsname, 1, 4) || substr(dsname, length(dsname) - 3, 4);
            else
                memname = dsname;

            xpt_path = "&xpt_dir\" || strip(memname) || ".xpt";

            call execute('libname xptlib xport "' || strip(xpt_path) || '";');

            /* Use PROC DATASETS to rename, then PROC COPY to transfer */
            if dsname ne memname then do;
                call execute('proc datasets library=inlib nolist; change ' || strip(dsname) || '=' || strip(memname) || '; quit;');
            end;

            call execute('proc copy in=inlib out=xptlib memtype=data; select ' || strip(memname) || '; run;');

            /* Rename back if needed */
            if dsname ne memname then do;
                call execute('proc datasets library=inlib nolist; change ' || strip(memname) || '=' || strip(dsname) || '; quit;');
            end;

            call execute('libname xptlib clear;');

            file "&errlog" mod;
            put "Converted to XPT: " dsname " -> " memname " (" xpt_path ")";

            if eof then do;
                put "----------------------------------------";
                put "Total SAS7BDAT files processed: " _n_;
            end;
        run;

        libname inlib clear;
    %end;

    %if &xpt_count > 0 %then %do;
        %let sdtm_dir = &outdir\DAC_SDTM;
        %let sdtm_exist = %sysfunc(fileexist(&sdtm_dir));

        %if &sdtm_exist = 0 %then %do;
            %put DEBUG: Creating directory &sdtm_dir;
            %let rc = %sysfunc(dcreate(DAC_SDTM, &outdir));
            %if %length(&rc) = 0 %then %do;
                %put ERROR: Failed to create directory &sdtm_dir;
                %abort;
            %end;
        %end;

        libname outsdtm "&sdtm_dir";

        data _null_;
            set file_list end=eof;
            where filetype = 'XPT';

            length dsname $32;

            dsname = scan(filename, 1, '.');

            call execute('libname xptlib xport "' || "&indir\" || strip(filename) || '";');
            call execute('proc copy in=xptlib out=outsdtm; run;');
            call execute('libname xptlib clear;');

            file "&errlog" mod;
            put "Converted to SAS7BDAT: " dsname;

            if eof then do;
                put "----------------------------------------";
                put "Total XPT files processed: " _n_;
            end;
        run;

        libname outsdtm clear;
    %end;

    %put DEBUG: Conversion process completed;

    data _null_;
        file "&errlog" mod;
        length dt $19;
        dt = put(datetime(), datetime19.);
        put "----------------------------------------";
        put "Process completed: " dt;
    run;

%mend convert_files;

%convert_files;
